package com.hyouteki.projects.memey.models

data class Help(
    val uid: String = "",
    val hid: String = "",
    val title: String = "",
    val desc: String = ""
)
