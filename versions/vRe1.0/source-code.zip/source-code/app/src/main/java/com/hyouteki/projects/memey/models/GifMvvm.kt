package com.hyouteki.projects.memey.models

data class GifMvvm(
    val gifUrl: String = "",
    val title: String = ""
)