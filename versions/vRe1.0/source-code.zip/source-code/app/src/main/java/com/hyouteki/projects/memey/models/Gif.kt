package com.hyouteki.projects.memey.models

data class Gif(
    val uid: String = "",
    val gid: String = "",
    val gifUrl: String = "",
    val title: String = ""
)